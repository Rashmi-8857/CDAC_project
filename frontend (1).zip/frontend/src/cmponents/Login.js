
// import React from 'react';

//  class Login extends React.Component
// {
//   constructor(props)
//   {
//     super(props)
//     this.state={
//       msg:""
//     }
//   }
//   checkLogin= ()=>{
//     let uid = this.refs.uid.value;
//     let pwd = this.refs.pwd.value;

//     const url = "http://localhost:8087/checkLogin?uid="+uid+"&pwd="+pwd;
//     fetch(url)
//     .then(Response => Response.text())
//     .then(data => {
//       if(data=="Admin")
//       this.props.history.push("/product/"+uid);

//     }
//     );
//   }   
  

//   render(){
//     return(
//       <div>
//         <h1 style={{textAlign:"center"}}>Login Datails</h1>
//         <form>
//         <table>
//         <tr>
//           <td>
//           Enter User Id  : </td>
//           <td>
//             <input type="text" ref="uid" /> <br/>
//           </td>
//           </tr>
//           <tr>
//           <td>
//           Enter Password : </td>
//           <td>
//           <input type="password" ref="pwd" /> <br/>
//           </td>
//           </tr>
//              <tr>
//                <td>
              
//                  <button type="submit" onClick={this.checkLogin}>Submit</button>
//                </td>
//                  <td>
//                  <form action="/register">
//                  <button type="submit">Register</button>
//                  </form>
//                 </td>
//                 </tr>
//                 </table>      
//         </form>
//         <br/>
//         <p>{this.state.msg}</p>
//       </div>
//     );
//   }
// }
// export default Login;





import React from 'react';
import "./stylee.css";

 class Login extends React.Component
{
  constructor(props)
  {
    super(props)
    this.state={
      msg:"",
      email:"",
      password:"",   
     }
  }
  checkLogin= (event)=>{
    console.log(event, "'hi");
    
         let email = this.refs.email.value;
     let password = this.refs.password.value;


     const url = `http://localhost:8087/check?email=${email}&password=${password}`;
     fetch(url)
     .then(Response => Response.text())
     .then(data => {
       const x = data.split(" ");
       localStorage.setItem("id", x[1] )
      if(x[0]=="admin")
      this.props.history.push(`/adminhome/${email}`);
      else if(x[0]=="customer")
      this.props.history.push(`/orders/${email}`);
  
    }
    );

    event.preventDefault();
}
  render(){
    return(
      <div>
       

        
      
        
	<body>
	<section className="ftco-section">
		<div className="containerr">
			<div className="row justify-content-center">
				<div className="col-md-6 text-center mb-4">
					<h2 className="heading-sectionn">Login</h2>
				</div>
			</div>
			<div className="row justify-content-center">
				<div className="col-md-12 col-lg-10">
					<div className="wrap d-md-flex">
						<div className="text-wrap p-4 p-lg-5 text-center d-flex align-items-center order-md-last">
							<div className="text w-100">
								<h2>Welcome to login</h2>
								<p>Don't have an account?</p>
								<a href="/register" className="btn btn-white btn-outline-white">Sign Up</a>
							</div>
			      </div>
						<div className="login-wrap p-4 p-lg-5">
			      	<div className="d-flex">
			      		<div className="w-100">
			      			<h3 className="mb-4">Sign In</h3>
			      		</div>
								<div className="w-100">
									<p className="social-media d-flex justify-content-end">
										<a href="#" className="social-icon d-flex align-items-center justify-content-center"><span className="fa fa-facebook"></span></a>
										<a href="#" className="social-icon d-flex align-items-center justify-content-center"><span className="fa fa-twitter"></span></a>
									</p>
								</div>
			      	</div>
							<form  onSubmit={this.checkLogin} className="signin-form">
			      		<div className="form-group mb-3">
			      			<label className="label" for="name">Username</label>
			      			<input type="text" className="form-control" ref="email" placeholder="Username" required/>
			      		</div>
		            <div className="form-group mb-3">
		            	<label className="label" for="password">Password</label>
		              <input type="password" className="form-control" ref="password" placeholder="Password" required/>
		            </div>
		            <div className="form-group">
		            	<button type="submit" className="form-control btn btn-primary submit px-3">Sign In</button>
		            </div>
		            <div className="form-group d-md-flex">
		            	<div className="w-50 text-left">
			            	<label className="checkbox-wrap checkbox-primary mb-0">Remember Me
									  <input type="checkbox" checked/>
									  <span className="checkmark"></span>
										</label>
									</div>
									<div className="w-50 text-md-right">
										<a href="#">Forgot Password</a>
									</div>
		            </div>
		          </form>
              <p>{this.state.msg}</p>
		        </div>
		      </div>
				</div>
			</div>
		</div>
	</section>

	<script src="js/jquery.min.js"></script>
  <script src="js/popper.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/main.js"></script>

	</body>
        </div>
        
      
      
    );
  }
}
export default Login;

