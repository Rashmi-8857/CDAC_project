import React from 'react'

class AdminHome extends React.Component {
    constructor(props) {
        super(props)

    }
    render() {
        return (
            <div>
                
                <h1 className="heading_style">Craft Foundry</h1>
                <br /> 
                <div className="centerr">
                <button className="btn btn-success"><a href="/product" className= "btn btn-success" >Add Products</a></button> 
                <br/>
                <br/>
                <button className="btn btn-primary"><a href="/ordertable" className="btn btn-primary">View Orders</a></button>
                <br/>
                <br/>
                <br/>       
                <br/> 
                </div> 
            </div>
        )}
}
export default AdminHome;