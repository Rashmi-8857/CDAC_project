
import React from 'react';
import ViewCakesTable from './ViewCakesTable';
import { toast } from 'react-toastify';
import "./style.css";



class Product extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      name: "",
      category: "",
      weight: "",
      price: "",
      description: "not bad",
    }
    this.productId = this.productId.bind(this);
    this.name = this.name.bind(this);
    this.category = this.category.bind(this);
    this.weight = this.weight.bind(this);
    this.price = this.price.bind(this);
    this.description = this.description.bind(this)
    this.submitInfo = this.submitInfo.bind(this);
  }

  productId = (event) => {
    this.setState({ productId: event.target.value })
  }
  name = (event) => {
    this.setState({ name: event.target.value })
  }

  category = (event) => {
    this.setState({ category: event.target.value })
  }

  weight = (event) => {
    this.setState({ weight: event.target.value })
  }
  price = (event) => {
    this.setState({ price: event.target.value })
  }
  description = (event) => {
    this.setState({ description: event.target.value })
  }

  handleSuccess = () => {
    toast("Added cake successfully")
  }

  handleFailure = () => {
    toast("Failed")
  }

  submitInfo = (e) => {

    const x = {
      // productId: e.target[0].value,
      name: e.target[0].value,
      category: e.target[1].value,
      weight: e.target[2].value,
      price: e.target[3].value,
      description: e.target[4].value,
    }

    fetch('http://localhost:8087/addproducts', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: e.target[0].value,
        category: e.target[1].value,
        weight: e.target[2].value,
        price: e.target[3].value,
        description: e.target[4].value,
      }),
    })
      .then(response => response.json())

      .then(data => {
        console.log('Success:', data);
        this.handleSuccess();
      })
      .catch((error) => {
        console.error('Error:', error);
        this.handleFailure();
      });  
    e.preventDefault();
  }
  render() {
    return (

      <div>

        <div>

          <h1 className="heading_style">Products</h1>
        </div>
        <div style={{backgroundColor:"white"}}>
          <form style={{ textAlign: "center" }} onSubmit={this.submitInfo}>

            <table >
              <div style={{backgroundColor:"white"}} >
                <tr>
                  <td > 
                    Enter Product  Name  : </td>
                  <td>
                    <input type="text" ref="" placeholder="name" className="form-control"/> <br />
                    <br />
                  </td>
                </tr>

                <tr>
                  <td>
                    Enter Category : </td>
                  <select class="Category" aria-label="Default select example" className="form-control">
                    <option selected>select category</option>
                    <option value="wooden Craft">wooden Craft</option>
                    <option value="Metal Craft">Metal Craft</option>
                    <option value="Painting">Painting</option>
                    <option value="Netting">Netting</option>
                    <option value="clay crafts">clay crafts</option>
                  </select>
                  <br />
                  <br />
                </tr>

                <tr>
                  <td>
                    Enter Quentity : </td>
                  <select class="Weight" aria-label="Default select example"  className="form-control">
                    <option selected>select Quentity</option>
                    <option value="More than ten">Nubmer of Items More Then 10</option>
                    <option value="single product">single Item</option>
                    <option value="more than one">more than one</option>
                  </select>
                  <br />
                  <br />
                </tr>
                <tr>
                  <td>

                    Enter Price : </td>
                  <td>
                    <input type="number" ref="" placeholder="price" className="form-control"/> <br />
                    <br />
                    <br />
                  </td>
                </tr>
                <tr>
                  <td>
                    Enter Product Descriptin  : </td>
                  <td>
                 
                    <input type="text" class="form-input" name="description" id="name" placeholder="description" className="form-control" />
                    
                    <br />
                  </td>
                </tr>
                <tr>
                  <td>
                  <form action="/action_page.php">    
                <label for="img">Select image:</label>
                <input type="file" id="img" name="img" accept="image/*" />
                </form>
                  </td>
                </tr>
              </div>
            </table>

            <button type="submit" className="btn btn-success">Add Product To Available</button>
            </form>


            <form>
            <br />
            <button className="btn btn-warning"><a href="/AdminHome">Back To Home</a></button>
            <br />
            <br />
            <button className="btn btn-danger"><a href="/Login">LogOut</a></button>
          </form>
        </div>
      </div>
    )
  }





}
export default Product;





