import React from "react";
import { MDBCol, MDBContainer, MDBRow, MDBFooter } from "mdbreact";

class confirmation extends React.Component 
{
  render() 
  {
    return (
      <MDBFooter color="blue" className="font-small pt-4 mt-4 footer">
      <div className="container">
      
      </div>
      <div className="footer-copyright text-center py-2" style={{ position:"fixed",width:"100%",top:"100px",backgroundColor:"#34ADF4",fontSize:"20px",fontWeight:"bold"}}>
      <MDBContainer fluid>
         <h1>Order Has Been Placed Successfull</h1>
        </MDBContainer>
      </div>
      <div style={{ width:"100%",top:"100px",marginTop:"200px",fontSize:"50px",fontWeight:"bold",textAlign:"center",fontFamily:"italic"}}>Thank You </div>
    </MDBFooter>
    );
  }
}
export default confirmation;