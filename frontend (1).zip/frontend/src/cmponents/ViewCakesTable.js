import React from 'react';
import { Link } from 'react-router-dom';
import logo from "./logo.png";
import "./style.css";


class ViewCakesTable extends React.Component
{
    constructor(props)
    {
        super(props);
        console.log(props)
        this.state = { cakesavailable: []};
        fetch("http://localhost:8087/craftdata")
        .then(response => response.json())
        .then(cakesavailable => (
            console.log(cakesavailable),
            this.setState({cakesavailable})),
      )
        
    }

    handleOrderSelect=(available)=>{

        console.log(available)

        this.props.history.push({
            pathname: `/payment`,
            state: { cake: available },
          });
    }
    
    render()
    {
    return(
        <div>
            <br/>
            <h1 className="heading_style" style={{marginTop:"10px"}}> Craft Available </h1>
            <br/><br/>


            <br/>

           
                  
                   
                    {
                        

                         this.state.cakesavailable.map(
                           available =>
                                    <div className="cards"  key={available.productId}>
                                        <div className="card ">
                                            <h2 className="card-title"> {available.name} </h2>
                                            <img src={"https://img3.exportersindia.com/product_images/bc-full/2021/5/8567618/watermark/handycraft-1614259638-5735284.jpeg"} alt="images" className="card__img" />
                                        <div className="card__info">
                                            <span className="card__title">{available.productid}</span>
                                            <span className="card__category"> {available.category}</span>
                                            <br/>
                                            <span className="card-description subtle">
                                            {available.decription}
                                            </span>
                                            <div className="card-read">Read</div>
                                      <button className="button" onClick={()=>this.handleOrderSelect(available)}>PlaceOrder</button>     
                                        </div>

                                        {/* <span className="card-tag  subtle">Order Now</span> */}
                                        </div>
                                
                                
                                    </div>
                                    
                                
                              
                               
                            )
                    }
                   
                
              
               

            <br/> <br/> <br/> <br/>

             <br/> <br/> <br/> <br/> <br/> <br/>            

        </div>
    );  
    }
}

export default ViewCakesTable;