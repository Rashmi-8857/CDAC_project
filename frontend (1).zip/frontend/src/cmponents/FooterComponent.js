import React from "react";
import { MDBCol, MDBContainer, MDBRow, MDBFooter } from "mdbreact";

const FooterPage = () => {
    return (
      <MDBFooter color="blue" className="font-small pt-4 mt-4 footer">
        <div className="container">
        
        </div>
        <div className="footer-copyright text-center py-2" style={{ position:"fixed",width:"100%",bottom:"0",backgroundColor:"#34ADF4",fontSize:"20px",fontWeight:"bold"}}>
        <MDBContainer fluid>
            &copy; {new Date().getFullYear()} Copyright: <a href=""> Craft Foundry</a>
          </MDBContainer>
        </div>
      </MDBFooter>
    );
  }
export default class FooterComponent extends React.Component {
    

    render() {
        return (
            FooterPage()
        )
    }
}