import { height } from "dom-helpers";
import React from "react";

class Home extends React.Component 
{
  render() 
  {
    return (
      <body style={{marginTop:"50px"}}>
      <div class="p-3 mb-2 bg-dark text-white" style={{textAlign:"center"}}>
        <h1 style={{textAlign: "center",color:"white"}}>Welcome To Craft Foundry</h1>
        <div style={{color:"white"}}>
        Address : Pune City
        <br/>
        Contact Us : 0212-2600172
        <br/>
        Time 11AM - 9PM 
        <br/>
        </div>
        <h1 style={{textAlign: "center"}}><p></p></h1>
       <div style={{width:"100%" ,height:"30%",contenta:"center",}}> <img src="https://miro.medium.com/max/1024/1*PayoA4N0mNfyp8r9L1KSDA.jpeg" width="95%" height="50%" class="centerr"/></div>
       
      </div>
      </body>
    );
  }
}
export default Home;