
import React from 'react';
import { toast } from 'react-toastify';
import { Link } from "react-router-dom";
import "./images/sstyle.css";



class Register extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      regid: "",
      name: "",
      email: "",
      password: "",
      contact: "",
      usertype:"customer"

    }
    this.regid = this.regid.bind(this);
    this.name = this.name.bind(this);
    this.email = this.email.bind(this);
    this.password = this.password.bind(this);
    this.contact = this.contact.bind(this);
    this.usertype = this.usertype.bind(this);
    this.submitInfo = this.submitInfo.bind(this);
  }
  regid = (event) => {
    this.setState({ regid: event.target.value })
  }

  name = (event) => {
    this.setState({ name: event.target.value })
  }

  email = (event) => {
    this.setState({ email: event.target.value })
  }

  password = (event) => {
    this.setState({ password: event.target.value })
  }

  contact = (event) => {
    this.setState({ contact: event.target.value })
  }
  usertype = (event) => {
    this.setState({ usertype: event.target.value })
  }

  handleSuccess = () => {
    toast("successfully Registered")
  }

  handleFailure = () => {
    toast("Registration Failed")
  }

  submitInfo = (e) => {

    console.log(this.state.name)
    fetch('http://localhost:8087/Register', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        regid: this.state.regid,
        name: this.state.name,
        email: this.state.email,
        password: this.state.password,
        contact: this.state.contact,
        usertype: this.state.usertype,
      }),
    })
      .then(response => response.json())
      .then(data => {
        console.log('Success:', data);
        this.props.history.push("/login")
        this.handleSuccess();
      })
      .catch((error) => {
        console.error('Error:', error);
        this.handleFailure();

      });

    e.preventDefault();

  }

  render() {
    return (
      <div >

        <body>

    <div className="main">

        <section className="signup">
             {/* <img src="images/signup-bg.jpg" alt=""> */}
            <div className="container">
                <div className="signup-contentt">
                    <form method="POST" id="signup-form" className="signup-form" onSubmit={this.submitInfo}>
                        <h2 className="form-title">Create account</h2>
                        <div className="form-group">
                            <input type="text" className="form-input" name="name" id="name" placeholder="Your Name" onChange={(event) => { this.name(event) }}/>
                        </div>
                        <div className="form-group">
                            <input type="email" className="form-input" name="email" id="email" placeholder="Your Email" onChange={(event) => { this.email(event) }}/>
                        </div>
                        <div className="form-group">
                            <input type="text" className="form-input" name="password" id="password" placeholder="Password" onChange={(event) => { this.password(event) }}/>
                            <span toggle="#password" className="zmdi zmdi-eye field-icon toggle-password"></span>
                        </div>
                        <div className="form-group">
                            <input type="password" className="form-input" name="number" placeholder="Enter Contact Number" onChange={(event) => { this.contact(event) }}/>
                        </div>
                        <div className="form-group">
                            <input type="checkbox" name="agree-term" id="agree-term" className="agree-term" />
                            <label for="agree-term" className="label-agree-term"><span><span></span></span>I agree all statements in  <a href="#" className="term-service">Terms of service</a></label>
                        </div>
                        <div className="form-group">
                            <input type="submit" name="submit" id="submit" className="form-submit" value="Sign up"/>
                        </div>
                    </form>
                    <p className="loginhere">
                        Have already an account ? <a href="/login" className="loginhere-link">Login here</a>
                    </p>
                </div>
            </div>
        </section>

    </div>

    {/* <!-- JS --> */}
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body>
      </div>
    )
  }

}
export default Register;