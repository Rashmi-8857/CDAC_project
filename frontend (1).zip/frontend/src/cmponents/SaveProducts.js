import React, {useState,useEffect} from 'react'

export const SaveProducts = () => {

    const [AllEntry, setAllEntry] = useState("[]");
    const [name, setname] = useState("");
    const [description, setdescription] = useState("");
    const [price, setprice] = useState("");
    
    const submitForm = (e) => {
       let data ={name,description,price}
        console.log(AllEntry);

        fetch('http://localhost:8087/addproducts', {
            method: 'POST',
            headers: {
               'Accept':'application/json', 
              'Content-Type': 'application/json',
            },
            body:JSON.stringify(data)
        }).then((result) => {
           result.json().then((resp) =>{
               console.warn("resp",resp)
           }) 
        })
    }
    return (
     
     <div>
    <div>
  <h1 className="heading_style">Products</h1>
</div>
<div style={{backgroundColor:"white"}}>
  <form style={{ textAlign: "center" }} onSubmit={submitForm}>

    <table >
      <div style={{backgroundColor:"white"}} >
        <tr>
          <td > 
            Enter Product  Name  : </td>
          <td>
            <input type="text"  placeholder="name" value={name}  onChange= {(e)=> setname(e.target.value)}  className="form-control"/> <br />
            <br />
          </td>
        </tr>

        <tr>
          <td>
            Enter Category : </td>
          <select class="Category" aria-label="Default select example" className="form-control">
            <option selected>select category</option>
            <option value="wooden Craft">wooden Craft</option>
            <option value="Metal Craft">Metal Craft</option>
            <option value="Painting">Painting</option>
            <option value="Netting">Netting</option>
            <option value="clay crafts">clay crafts</option>
          </select>
          <br />
          <br />
        </tr>

        <tr>
          <td>
            Enter Quentity : </td>
          <select class="Weight" aria-label="Default select example"  className="form-control">
            <option selected>select Quentity</option>
            <option value="More than ten">Nubmer of Items More Then 10</option>
            <option value="single product">single Item</option>
            <option value="more than one">more than one</option>
          </select>
          <br />
          <br />
        </tr>
        <tr>
          <td>

            Enter Price : </td>
          <td>
            <input type="text" value={price} placeholder="price"   onChange= {(e)=> setprice(e.target.value)} className="form-control"/> <br />
            <br />
            <br />
          </td>
        </tr>
        <tr>
          <td>
            Enter Product Descriptin  : </td>
          <td>
         
            <input type="text" class="form-input" name="description" id="name" value={description} placeholder="description" className="form-control"  onChange= {(e)=> setdescription(e.target.value)}/>
            
            <br />
          </td>
        </tr>
        <tr>
          <td>
          <form action="/action_page.php">    
        <label for="img">Select image:</label>
        <input type="file" id="img" name="img" accept="image/*" />
        </form>
          </td>
        </tr>
      </div>
    </table>

    <button type="submit"  onSubmit={submitForm} className="btn btn-success" >Add Product To Available</button>
    </form>


    <form>
    <br />
    <button className="btn btn-warning"><a href="/AdminHome">Back To Home</a></button>
    <br />
    <br />
    <button className="btn btn-danger"><a href="/Login">LogOut</a></button>
  </form>
</div>
</div>
     
     
    )
}
