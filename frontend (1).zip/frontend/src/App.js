import React from "react";

import { Link,Route,Switch } from "react-router-dom";
import Navbar from "./cmponents/navbar";
import Home from "./cmponents/Home";
import Login from "./cmponents/Login";
import Register from "./cmponents/Register";
import Product from "./cmponents/product";
import Payment from "./cmponents/payment";
import AdminHome from "./cmponents/AdminHome";
import Orders from "./cmponents/Orders";
import OrderTable from "./cmponents/OrderTable";
import ViewCakesTable from "./cmponents/ViewCakesTable";
import confirmation from "./cmponents/confirmation";
import { ToastContainer } from 'react-toastify';
import { Form } from "react-bootstrap";
// import menuCard from "./cmponents/MenuCard";
import FooterComponent from "./cmponents/FooterComponent.js"
import { SaveProducts } from "./cmponents/SaveProducts";

export default function App() {
  return (

<React.Fragment>
  <ToastContainer/>
  <Navbar/>


    <div>
      <div>
      <Switch>
  
        <Route path="/" component={Home} exact />
        <Route path="/login" component={Login} exact />
        <Route path="/register" component={Register} />
        <Route path="/product" component={Product} />
        <Route path="/payment" component={Payment} />
        <Route path="/adminhome" component={AdminHome} />
        <Route path="/Orders" component={ViewCakesTable} />
        <Route path="/ordertable" component={OrderTable} />
        <Route path="/viewcakestable" component={ViewCakesTable} />
        <Route path="/confirmation" component={confirmation}  /> 
        {/* <Route path="/menucard" component={menuCard}/> */}
        <Route path="/form" component={Form}  /> 
        {/* <Route path= "/product" component={SaveProducts} /> */}
        <Route path="/footerComponent" component={FooterComponent}  /> 
      
        
        </Switch>

      </div>
    </div>
    <FooterComponent/>
    </React.Fragment>
  );
}



